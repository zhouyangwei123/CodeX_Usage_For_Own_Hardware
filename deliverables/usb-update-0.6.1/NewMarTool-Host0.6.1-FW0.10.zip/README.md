# Host0.6.1 / App0.10 / Boot1.0

[下载测试包](NewMarTool-Host0.6.1-FW0.10.zip)。本包已完成离线检查、USB实际写入与回读、20轮重连、5分钟通信及实体显示确认，范围是一块STM32G474RB/128KiB板。

默认本机Token用量与固定波形页，不自动轮播；上位机默认像素皮肤，带顶部留白与马赛克边框。托盘“用量来源”可手动切换账号日汇总，外观菜单保留其他皮肤。日汇总可能延迟，不能当成逐秒速率。

已安装Boot1.0的设备，更新时只选`Application-0.10.bin`，不要重复首次完整安装或解除启动区保护。入口：“诊断与设置 → 设备固件升级”，选择已安装的STM32CubeProgrammer CLI；本轮使用2.23.0与已安装的WinUSB驱动。当前电脑已更新并恢复本机波形页。

新板首次安装仍可用包内Install-STLink.ps1；本机这次升级完全通过USB。KEY1恢复使用未改变的Boot1.0。完整实测范围与构建区别见[验收记录](https://github.com/zhouyangwei123/CodeX_Usage_For_Own_Hardware/blob/feat/account-oled-pixel-20261023/docs/USB_OLED-20261023.md)。本轮不包含8小时、睡眠、反复物理拔插或升级中断电验证。

包内只有程序、固件、脚本和说明，不包含个人配置或认证。最终EXE SHA-256：`d6e420d4c715b4c831d08c5aa2c6d6b3563c0e099320bc71414ccd2d828016a0`。使用SHA256SUMS核对文件完整性。
