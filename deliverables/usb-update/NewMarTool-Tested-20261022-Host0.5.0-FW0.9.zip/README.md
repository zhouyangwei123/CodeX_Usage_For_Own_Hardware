# Host0.5.0 / App0.9 / Boot1.0 已测试开发版本

2026-10-22整理。EXE与固件保持当天实测的原始字节，本包没有修复已知缺陷。不是正式验收通过的发布版。

1. 完整解压；在Windows PowerShell运行 `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Verify-Package.ps1`，只核对文件，不访问设备。
2. 先读 `VALIDATION.md` 和 `KNOWN_ISSUES.md`。原始测试输出在 `Evidence/`。
3. 本次已测试的板卡已经安装并保护Boot1.0，当前App0.9。不要重复执行 `Install-STLink.ps1 -Install`，也不要全片擦除或自动解除保护。
4. 换电脑安装完整STM32CubeProgrammer及DFU驱动，今天USB路径验证的是2.23.0。工具从ST官方下载：https://www.st.com/en/development-tools/stm32cubeprog.html 。本包不含ST安装程序和驱动。
5. 退出其他占用板卡的上位机。运行本包 `CodexToolsHost.exe`，在设置中确认新电脑的串口与板卡身份；原机COM8不是固定编号。本板USB序列号20553872524E。
6. 应用更新选择本包 `Application-0.9.bin` 和新电脑实际安装的 `STM32_Programmer_CLI.exe`。当前产品未绑定切换前后的板卡身份，因此更新时只连接目标板；升级期间不要从托盘退出。
7. 无法正常连接应用时，断开全部供电，按住KEY1（PC3）接回USB，检测到DFU后松开，再在升级页面选择有效应用。此路径本次已实际验证。

普通应用更新可只带USB数据线；继续固件开发建议携带ST-Link及连接线。修改启动程序、保护或启动设置、USB完全不可用及现场调试仍可能需要它。

`BenchSources/`保存当时实机测试源文件，部分包含固定本机路径或会故意写入不完整应用，不是日常升级入口，不能直接照搬执行。`ReviewSources/`为离线缺陷复现源文件，退出0表示缺陷被复现。

当前源码与完整接手记录位于Git分支 `review/usb-ota-20261022`：
https://github.com/zhouyangwei123/CodeX_Usage_For_Own_Hardware/tree/review/usb-ota-20261022

本包不包含个人配置、API Key、Codex登录资料或整片Flash备份。原始离线说明保留于 `OFFLINE-TEST-RESULTS.txt`；最新实际范围以VALIDATION为准。
