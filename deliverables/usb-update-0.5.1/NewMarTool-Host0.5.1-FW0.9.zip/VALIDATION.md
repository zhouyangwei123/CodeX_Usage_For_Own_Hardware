# 0.5.1 USB 升级安全修复与本机验收

基线为 `review/usb-ota-20261022` / `ea643ff`。用户要求修复三项审查问题、更新本机、离线和实机验证后推送分支，并规划 OLED 与 USB 调试。本轮上位机为0.5.1，未修改App0.9 / Boot1.0源码和布局。

## 修复行为

1. 正常升级前从当前CDC串口的Windows PNP身份取得USB序列号，进入DFU前再次核对。更新器必须收到预先确认的身份；若DFU只出现另一序列号，立即拒绝，连该设备的内存都不读取。无串口的恢复流程先“识别设备”，在确认框显示并绑定序列号，后续操作不改变目标。
2. 升级状态由BridgeService统一持有，同一时刻只允许一个升级。托盘退出和ApplicationContext.ExitThread在清理窗口、设备服务前检查状态；升级结束后才释放。设置窗口普通关闭限制保留。完成与错误路径均在恢复串口后释放状态。
3. 首次安装在第一次写入前检查WRP1B是否覆盖安装范围，同时检查Bank1 PCROP。按当前DBANK计算页大小和最后受影响页；遇到冲突停止，不自动解除保护。安装区域外的WRP1B保留。
4. 移除浮窗悬停ToolTip，保留折叠、拖动、额度与底栏；主动保存失败时仍提示错误。

## 离线验证

| 项目 | 结果 |
|---|---|
| 原三项复现 | 修复前均复现；修复后已转安全回归 |
| 更新器/首次安装 | 55项通过；覆盖错误/缺失身份、两种页大小下的WRP1B、PCROP与区域外保护 |
| 三项安全回归 | 引用实际0.5.1 EXE；错误板0次内存操作，保护冲突0次写入，真实托盘退出与ExitThread被拦截 |
| 生产C镜像/升级请求 | 9项、3项通过 |
| USB传输/原协议 | 22项、16项通过，含100,000次模拟传输与1,000次模拟USB重置 |
| 上位机内置检查 | 自检86、模拟闭环4、UI批量15、第二阶段10个布尔检查全部为true，各退出0 |
| Token HUD | 77项通过 |
| PowerShell 5.1安装入口 | 中文/空格路径安全拒绝无设备，通过 |
| 升级页面 | 新增身份行后1020×760离屏渲染可读，无截断 |
| OLED布局Demo | 18种组合无像素越界，交互变化、390像素页面宽度和JS检查通过 |

20261022实机夹具保持原字节，继续针对原0.5.0 EXE。三项安全回归已改为引用实际0.5.1 EXE；新实机夹具位于 `tests/usb_update/bench_20261023/`。

## 本机实测与部署

识别到ST-Link及同一块STM32G474RB / 128 KiB板卡，串口为COM6。只读核对得到Boot1.0/App0.9，CRC与交付镜像匹配，WRP1A保护前8KiB，WRP1B未启用。串口测试和实际USB重写后的前64KiB Flash、选项字节均与测试前完全一致；最终只读核对使用SWD Hot Plug，不改保护设置。

新版生产SerialLink通过10次Reconnect与10次Pause/Start，均取得新握手和INFO。随后连续通信300.008秒，1192/1192回显，无未回答或意外回显、运行时间倒退及意外断连，最大往返8ms；释放后独占打开检查成功。这不是8小时验收，也不覆盖系统睡眠或物理拔插。

这次串口测试的EXE为0.5.1早期构建，SHA-256为 `a2cf82b0fc16b5e862f79192ad40dc4cf9c120a4cb4b0e7da10b75e4adb08c98`。之后仅清理WMI资源释放及悬停说明相关代码，SerialLink实现未变。下述USB实测、本机安装与交付包均使用最终构建 `ef2cb6efa403a30759ea9ed23fda571741325071b79118ff8352e005dc27be2b`。

原上位机0.4.2已正常退出，原EXE与配置留有本地备份；安装目录EXE已更新为0.5.1并启动。个人配置、认证与芯片备份不纳入仓库。

### USB升级实测通过

2026-10-23 09:30（UTC+8），使用完整STM32CubeProgrammer 2.23.0完成真实USB升级，设备身份为 `20553872524E`。测试后系统DFU驱动属性为WinUSB 1.3.0.0 / `oem49.inf`。验证如下：

- 从实际CDC身份进入ROM DFU，使用故意不匹配的预期身份；更新器拒绝，内存读写命令为0。
- 绑定正确身份，读取并验证启动区和保护设置，备份原应用，实际写入App0.9；工具校验和45,384字节逐字节回读均通过。
- 实际写入阶段调用真实托盘退出入口和ExitThread；共享升级状态均阻止退出。
- 自动跳转Boot1.0后重新枚举COM6，生产SerialLink重新取得App0.9 INFO。
- 最终前64KiB Flash SHA-256为 `af79da65fd0a290ececc117903ef6b73b715b3b19f05065ffea2cde3662fe2bb`，选项字节为 `376a7c2373875af69a759025367692f46f521dd5dc119b46ab4207f7418a634f`，均与测试前一致。

原始命令日志和完整芯片备份留在本地忽略目录 `artifacts/safety-20261023/hardware-usb-full223/`；可公开的结果摘要见 [本机验收证据](https://github.com/zhouyangwei123/CodeX_Usage_For_Own_Hardware/blob/fix/usb-update-safety-20261023/docs/evidence/usb-safety-20261023.json)。测试后已恢复正常CDC连接并重启本机安装的0.5.1。

此前两次尝试分别因缺驱动、旧ST DFU驱动与CubeIDE精简2.17工具不匹配而停止，均没有写入Flash，保留失败记录。当时自动审批拒绝代为管理员安装（`blocked by policy`）；用户随后提供完整2.23.0安装目录，继续测试时兼容WinUSB已可用。本轮没有重试被拒绝的提权操作。

WRP1B/PCROP冲突在模拟设备验证；本机板卡已保护启动区，不重复首次安装或为了测试改写保护。

此次验证限于这块128KiB板卡、App0.9和上述工具/驱动组合；尚未覆盖长时间运行、系统睡眠、更新中物理断电或所有Windows环境。封装工具原始 `firmware-manifest.json` 的 `hardware_tested:false` 保留为构建时标记，不能替代这里逐项记录的实测范围。

## 重现

```powershell
./host/build.ps1
./tests/usb_update/run.ps1 -PackageDirectory '<含App0.9和Boot1.0 BIN的解压目录>'
./tests/usb_update/review_20261022/run.ps1 -PackageDirectory '<同一解压目录>'
./tests/token_hud/run.ps1
./tests/usb_transport/run.ps1
./tests/protocol_pc/run.ps1
```

实机夹具先确认串口、USB序列号及独占使用状态。UsbSafetyBench执行真实应用升级，不能当作只读探测。日志、备份和部署备份在忽略的 `artifacts/safety-20261023/`；后续规划见 [NEXT_DEMO-20261023.md](https://github.com/zhouyangwei123/CodeX_Usage_For_Own_Hardware/blob/fix/usb-update-safety-20261023/docs/NEXT_DEMO-20261023.md)。
