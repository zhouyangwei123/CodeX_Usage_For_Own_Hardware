﻿Host0.6.2

修复Codex分页日志漏读，启动按原时间补回最近一小时用量曲线。
退出上位机，将CodexToolsHost.exe覆盖到原安装目录后启动。保留原CodexToolsHost.json，不需要更新设备固件（继续使用App0.10）。
纵轴单位为Token/分钟，整小时无用量时最低刻度0、0.5、1属于正常情况。

EXE SHA-256: 23d7f96f27ef3a69a681eed01d35043ef70445cb785e733766c217251df5803c
